
	               *****
	    http://photoshopix.com
	
	Free Photoshop video tutorials on:

		- Retouching
		- Collage
		- Text Effects
		- Designing site templates
		- Buttons
		etc.


	Also you can find:
	
		- Brushes
		- Actions
		- Styles
		- Gradients
		- Shapes
		- Fonts
		- PSD templates
		etc.

	Thank you for visiting our site!
	
	               *****
	    http://photoshopix.com
	